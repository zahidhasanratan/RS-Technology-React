<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MoneyReceipt extends Model
{
    //
}
