<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PreviousProgram extends Model
{
    //
}
