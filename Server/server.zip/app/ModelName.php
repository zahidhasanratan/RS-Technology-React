<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelName extends Model
{
    //
}
