<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LifeMember extends Model
{
    protected $table = 'lifemember';
}
