<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NeedHelp extends Model
{
    //
}
