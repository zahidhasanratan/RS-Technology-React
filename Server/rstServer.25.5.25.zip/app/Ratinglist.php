<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ratinglist extends Model
{
    //
}
