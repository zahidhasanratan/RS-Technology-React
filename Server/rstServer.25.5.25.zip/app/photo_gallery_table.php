<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class photo_gallery_table extends Model
{
    //
}
